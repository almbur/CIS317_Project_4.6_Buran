/*******************************************************************
* Name: Almaz Buran
* Date: Jan 7, 2024
* Assignment: CIS317 Week 3 PA 3.7
*
* 
*/
// Interface to represent items that can be purchased
public interface IPurchasable
{
    double Price { get; }
}